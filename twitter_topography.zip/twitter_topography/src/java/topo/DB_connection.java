/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package topo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

/**
 *
 * @author vishvaka
 */
public class DB_connection {
    public Connection connection;
    public Statement statement;
    public void connect_to_topo()
    {
        try {
         Class.forName("oracle.jdbc.driver.OracleDriver");
         connection = DriverManager
            .getConnection("jdbc:oracle:thin:@localhost:1522:rahul","topo","topo");
         System.out.println("Opened database successfully");
         
      } catch (Exception e) {
         e.printStackTrace();
         System.err.println(e.getClass().getName()+": "+e.getMessage());
         System.exit(0);
      }
    }
}
