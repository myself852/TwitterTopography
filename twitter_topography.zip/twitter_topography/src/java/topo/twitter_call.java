/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package topo;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import twitter4j.TwitterException;

import topo.searchTweet;
/**
 *
 * @author vishvaka
 */
public class twitter_call extends Friendship{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws TwitterException, SQLException, ParseException, ParserConfigurationException, SAXException, IOException {
        // TODO code application logic here
       
        Friendship f = new Friendship();
        DB_connection con = new DB_connection();
        //f.follower_C();
        //f.friend_C();
        //f.user_u();
        //f.updateFOLLOWER_FRIEND_C();
       
        
        //writeJSON w = new writeJSON();
        //w.saveJSON();
      //  
       // 
      
      //readJSON r = new readJSON();  
      //r.rawJSON();
        
       
       //topo.searchTweet s = new topo.searchTweet();
       //s.search("BJP Congress");
       
       topo.homeTimelineLocation h = new topo.homeTimelineLocation();
       h.home_loc();
        
    }
    
}
