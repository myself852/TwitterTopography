/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package topo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 *
 * @author vishvaka
 */
public class DB_validate extends Friendship{
    
    //String today = dateFormat.format(cal.getTime());
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException, ParseException {
        // TODO code application logic here
        
       
        DB_connection open_connection = new DB_connection();
       open_connection.connect_to_topo();
       open_connection.statement = open_connection.connection.createStatement();
       String Follower_CHECK = "select * from  FOLLOWER";
       ResultSet rs= open_connection.statement.executeQuery(Follower_CHECK);  
       int count = 0;
       String dateinstring = null;
       SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
        //getting the record of 3rd row  
        while(rs.next())
        {
             count = rs.getInt(1);
             dateinstring = rs.getString(2);
        } 
        System.out.println(count+ " "+dateinstring );
        Date follower_date = formatter.parse(dateinstring);
        System.out.println(follower_date);
        //System.out.println("Follower Date "+formatter.format(follower_date));  
       DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
       Calendar cal = Calendar.getInstance();
       Date today_date = formatter.parse(dateFormat.format(cal.getTime()));
       System.out.println("Today's date"+today_date);
       
        long diff = today_date.getDate()-follower_date.getDate();
        System.out.println(diff);
        
       
        
       open_connection.statement.close();
       open_connection.connection.commit();
       open_connection.connection.close();  
       
    
       

        
    }
    
}
