/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package topo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.sql.ResultSet;
import java.util.Date;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import twitter4j.IDs;
import twitter4j.Status;
import twitter4j.StreamController.User;
import twitter4j.TwitterException;
import twitter4j.TwitterObjectFactory;

/**
 *
 * @author vishvaka
 */
public class Friendship extends twitterAuth {
    DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
    Calendar cal = Calendar.getInstance();
    int follower_count=0;
    int friend_count =0;
    int follow_count_in_28_days=0;
    
    
    public int follower_C() throws TwitterException, SQLException {
        long lCursor = -1;
        IDs followersIDs = twitter.getFollowersIDs("@IGNOUtopography", lCursor);
        follower_count = followersIDs.getIDs().length;
        System.out.println("Follower"+follower_count);
        
        //INSERTING COUNT INTO TOPO DATABASE
       /*System.out.println(dateFormat.format(cal.getTime()));
       DB_connection open_connection = new DB_connection();
       open_connection.connect_to_topo();
       open_connection.statement = open_connection.connection.createStatement();
       String insertFollower_C = "INSERT INTO FOLLOWER VALUES("+follower_count+","+dateFormat.format(cal.getTime())+")";
       open_connection.statement.executeUpdate(insertFollower_C);
       open_connection.statement.close();
       open_connection.connection.commit();
       open_connection.connection.close(); */
       return follower_count;
        
    }
    
   

    

    public int friend_C() throws TwitterException {
        long FrCursor = -1;
        IDs friendsIDs = twitter.getFriendsIDs("@IGNOUtopography", FrCursor);
        friend_count = friendsIDs.getIDs().length;  // to get the count of friend 
        System.out.println("Friend"+friend_count);
        return friend_count;
    }
    
    
    
    public twitter4j.User user_u() throws TwitterException {
        twitter4j.User user = twitter.verifyCredentials();
        return user;
    }
    
    // Code to get the HomeTimeline status 
    public List<Status> status() throws TwitterException {
        List<Status> statuses = twitter.getUserTimeline();
        
        return statuses;
    }
    
    public List<Status> mention_tweet() throws TwitterException
    {
        twitter4j.User user = twitter.verifyCredentials();
            List<Status> tweet = twitter.getMentionsTimeline();
        return  tweet;
    }
    
    
    
    //Code to get the mentioned tweets
    public int mention()
            {
                int mention_count =0;
                try {
            twitter4j.User user = twitter.verifyCredentials();
            List<Status> statuses = twitter.getMentionsTimeline();
            System.out.println("Showing @" + user.getScreenName() + "'s mentions.");
            for (Status status : statuses) {
                System.out.println("@" + status.getUser().getScreenName() + " - " + status.getText());
                mention_count++;
            }
            
        } catch (TwitterException te) {
            te.printStackTrace();
            System.out.println("Failed to get timeline: " + te.getMessage());
            System.exit(-1);
        }
                return mention_count;
                
            }
    
    public List<Status> myliked() throws TwitterException
    {
     List<Status> likeStat = twitter.getFavorites();
     return likeStat;
    }
    
    // Code to get number of likes
    public int likes()
    {
        int like_count = 0;
        try {
            //Twitter twitter = new TwitterFactory().getInstance();
            List<Status> statuses = twitter.getFavorites();
            for (Status status : statuses) {
                System.out.println("@" + status.getUser().getScreenName() + " - " + status.getText());
                like_count++;
            }
            System.out.println("like count "+like_count);
            System.out.println("done.");
           // System.exit(0);
        } catch (TwitterException te) {
            te.printStackTrace();
            System.out.println("Failed to get favorites: " + te.getMessage());
            System.exit(-1);
        }
        return like_count;
    }
     
    
    //=========================================================================
    
    public int updateFOLLOWER_FRIEND_C() throws SQLException, ParseException{
        System.out.println(dateFormat.format(cal.getTime()));
        
        DB_connection open_connection = new DB_connection();
       open_connection.connect_to_topo();
       open_connection.statement = open_connection.connection.createStatement();
       String insertFollowerwithdate_C = "UPDATE FOLLOWER SET FOLLOWER_COUNT ="+follower_count+",FOLLOWER_DATE="+dateFormat.format(cal.getTime())+" where ID = 1";
       String insertFollower_C = "UPDATE FOLLOWER SET FOLLOWER_COUNT ="+follower_count+" where ID = 1";
       String insertFriend_C = "INSERT INTO FRIEND VALUES ("+friend_count+","+dateFormat.format(cal.getTime())+")";
        String Follower_CHECK = "select * from  FOLLOWER";
       ResultSet rs= open_connection.statement.executeQuery(Follower_CHECK);  
       int count = 0;
       String dateinstring = null;
       SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
        //getting the record of 3rd row  
        while(rs.next())
        {
             count = rs.getInt(1);
             dateinstring = rs.getString(2);
        } 
        System.out.println(count+ " "+dateinstring );
        Date follower_date = formatter.parse(dateinstring);
        System.out.println(follower_date);
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
       Calendar cal = Calendar.getInstance();
       Date today_date = formatter.parse(dateFormat.format(cal.getTime()));
       long diff = today_date.getDate()-follower_date.getDate();
       
       if(diff >= 0 && diff<= 28 )
       {
           if(count < follower_count)
           {
           follow_count_in_28_days = follower_count-count;
           open_connection.statement.addBatch(insertFollower_C);
           System.out.println("Follower increased "+follow_count_in_28_days);
           }else if (count > follower_count)
           {
               follow_count_in_28_days = follower_count-count;
               open_connection.statement.addBatch(insertFollower_C);
               System.out.println("Follower Decreased "+follow_count_in_28_days);
           }
       }
       else
       {
           if(count < follower_count)
           {
           follow_count_in_28_days = follower_count-count;
           open_connection.statement.addBatch(insertFollowerwithdate_C);
           System.out.println("Follower increased "+follow_count_in_28_days);
           }else if (count > follower_count)
           {
               follow_count_in_28_days = follower_count-count;
               open_connection.statement.addBatch(insertFollowerwithdate_C);
               System.out.println("Follower Decreased "+follow_count_in_28_days);
           }
           
       }
           
       open_connection.statement.addBatch(insertFriend_C);
       open_connection.statement.executeBatch();
       open_connection.statement.close();
       open_connection.connection.commit();
       open_connection.connection.close(); 
       
       return follow_count_in_28_days;
    }
    
    
    
}
