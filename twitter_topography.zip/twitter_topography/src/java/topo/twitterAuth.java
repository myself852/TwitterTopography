/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package topo;
import twitter4j.*;
import java.util.*;
import twitter4j.conf.ConfigurationBuilder;
/**
 *
 * @author vishvaka
 */
public class twitterAuth extends DB_connection{
     
    
   static ConfigurationBuilder cb = new ConfigurationBuilder().setDebugEnabled(false).setJSONStoreEnabled(true).setOAuthConsumerKey("<consumer key>").setOAuthConsumerSecret("<consumer secret key>")
	        .setOAuthAccessToken("Access token")
	        .setOAuthAccessTokenSecret("Access token secret");
        
       static TwitterFactory tf = new TwitterFactory(cb.build());
       public static twitter4j.Twitter twitter = tf.getInstance();
   
}
