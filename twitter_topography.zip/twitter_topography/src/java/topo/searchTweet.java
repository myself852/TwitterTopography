/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package topo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import twitter4j.Query;
import twitter4j.QueryResult;
import twitter4j.Status;
import twitter4j.TwitterException;

/**
 *
 * @author vishvaka
 */
public class searchTweet extends twitterAuth{
    
     
    
    
    public void search(String q) throws MalformedURLException, IOException, ParserConfigurationException, SAXException, SQLException
    {
        ArrayList<String> latlng = new ArrayList<String>();
        DB_connection open_connection = new DB_connection();
       open_connection.connect_to_topo();
       String insert = "insert into QUERIED_GEO values(?)";
       open_connection.connection.createStatement().executeUpdate("TRUNCATE TABLE QUERIED_GEO");
       System.out.println("QUERIED_GEO table truncated");
       PreparedStatement ps = open_connection.connection.prepareStatement(insert);
        try {
            Query query = new Query(q);
            QueryResult result;
            do {
                result = twitter.search(query);
                List<Status> tweets = result.getTweets();
                for (Status tweet : tweets) {
                    
                    //System.out.println("@" + tweet.getUser().getScreenName() + " - " + tweet.getText());
                    if(tweet.getUser().isGeoEnabled() == true && tweet.getUser().getLocation() != null && tweet.getUser().getLocation().isEmpty() == false)
                    {
                        System.out.println(tweet.getUser().getLocation());
                try
                {
                String url = "https://maps.googleapis.com/maps/api/geocode/xml?address="+tweet.getUser().getLocation().replace(" ", ",")+"&key=AIzaSyBbivtHkkAIXuQ6LsAlIl-bUwz7ihWk6WI";  
                System.out.println(url);
                
                URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();

		// optional default is GET
		con.setRequestMethod("GET");

		//add request header
		con.setRequestProperty("User-Agent", "Mozilla/5.0");

		int responseCode = con.getResponseCode();
		//System.out.println("\nSending 'GET' request to URL : " + url);
		//System.out.println("Response Code : " + responseCode);

		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream(),Charset.forName("UTF-8")));
                
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		//print result
		//System.out.println(response.toString());
               
                DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
                InputSource src = new InputSource();
                src.setCharacterStream(new StringReader(response.toString()));
                
                Document doc = builder.parse(src);
                //String age = doc.getElementsByTagName("age").item(0).getTextContent();
                //String name = doc.getElementsByTagName("name").item(0).getTextContent();
                
                //System.out.println("lat : " + doc.getElementsByTagName("lat").item(0).getTextContent());
                //System.out.println("lng : " + doc.getElementsByTagName("lng").item(0).getTextContent());
                
                 latlng.add("{lat: " + doc.getElementsByTagName("lat").item(0).getTextContent()+ "," +"lng: " + doc.getElementsByTagName("lng").item(0).getTextContent()+"},")  ;
                }
                catch(IOException ie)
                {
                    latlng.add("{lat: " + 37.4223582+ "," +"lng: " + -122.0844464+"},")  ;
                }
                catch(NullPointerException ex)
                {
                    latlng.add("{lat: " + 37.4223582+ "," +"lng: " + -122.0844464+"},")  ;
                }
                        
                    }
                    
                }
            } 
            while ((query = result.nextQuery()) != null);
            
            
            for(String s: latlng){
                ps.setString(1,s);
                ps.addBatch();
                System.out.println(s);
            }
            ps.executeBatch();
            
            //System.exit(0);
        } catch (TwitterException te) {
            te.printStackTrace();
            System.out.println("Failed to search tweets: " + te.getMessage());
            //System.exit(-1);
        }
        
    }
    
}
